# Digital Books Theme | قالب الكتب الرقمية 📚

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.8+-green.svg)
![WooCommerce](https://img.shields.io/badge/WooCommerce-Required-purple.svg)
![PHP](https://img.shields.io/badge/PHP-7.4+-orange.svg)

**قالب ووردبريس متكامل لإدارة وبيع الكتب الرقمية مع WooCommerce**

A complete WordPress theme for managing and selling digital books with WooCommerce integration.

---

## ✨ المميزات | Features

### 📚 إدارة الكتب المتقدمة
- ✅ Custom Post Type للكتب
- ✅ رفع وإدارة ملفات PDF
- ✅ صور غلاف احترافية
- ✅ تصنيفات مخصصة للكتب
- ✅ وصف تفصيلي لكل كتاب
- ✅ دمج كامل مع WooCommerce

### 💳 نظام الدفع عبر WooCommerce
- ✅ **تحويل تلقائي للكتب إلى WooCommerce Products**
- ✅ **الدفع عبر WooCommerce Checkout** (جميع طرق الدفع المدعومة)
- ✅ **إدارة الطلبات عبر WooCommerce**
- ✅ **تحميل ملفات PDF بعد الشراء**
- ✅ **زر "قراءة الآن" في My Account**
- ✅ **إعادة توجيه تلقائية للقراءة بعد الشراء**

### 📖 قارئ PDF احترافي
- ✅ PDF.js 3.11.174 مع text layer
- ✅ تحديد ونسخ النص
- ✅ Zoom (50% - 300%)
- ✅ Fullscreen Mode
- ✅ الروابط تفتح في تاب جديد
- ✅ حفظ تقدم القراءة تلقائياً
- ✅ اختصارات لوحة المفاتيح

### 🎧 نظام الصوت مع QR Codes
- ✅ ربط ملفات صوتية بصفحات محددة
- ✅ تشغيل تلقائي عند الانتقال للصفحة
- ✅ مشغل صوتي احترافي
- ✅ دعم جميع صيغ الصوت

### 🎨 تصميم عصري
- ✅ تصميم Responsive كامل
- ✅ دعم RTL للعربية
- ✅ SweetAlert2 للإشعارات
- ✅ Gradients حديثة
- ✅ Smooth Animations
- ✅ Dark Mode Support

---

## 🔧 المتطلبات | Requirements

| المتطلب | الإصدار |
|---------|---------|
| **WordPress** | 5.8+ |
| **PHP** | 7.4+ |
| **MySQL** | 5.6+ |
| **WooCommerce** | 5.0+ ⚠️ **مطلوب** |
| **الذاكرة** | 128MB+ |
| **مساحة التخزين** | 500MB+ |

> ⚠️ **مهم جداً:** يجب تثبيت وتفعيل بلاجن **WooCommerce** أولاً قبل تفعيل الثيم!

---

## 📥 التثبيت | Installation

### الخطوة 1: تثبيت WooCommerce

```
1. لوحة التحكم → إضافات → أضف جديد
2. ابحث عن "WooCommerce"
3. قم بالتثبيت والتفعيل
4. اتبع معالج الإعداد الأولي
```

### الخطوة 2: تثبيت الثيم

#### الطريقة الأولى: عبر لوحة التحكم
```
1. لوحة التحكم → المظهر → قوالب → أضف جديد
2. اضغط "رفع قالب"
3. اختر ملف digital-books-theme.zip
4. اضغط "التثبيت الآن"
5. اضغط "تفعيل"
```

#### الطريقة الثانية: عبر FTP
```bash
# رفع المجلد إلى:
wp-content/themes/digital-books-theme/

# ثم تفعيل الثيم من لوحة التحكم
```

### الخطوة 3: الإعداد الأولي

بعد تفعيل الثيم سيتم تلقائياً:
- ✅ إنشاء جداول قاعدة البيانات
- ✅ إنشاء مجلدات التخزين
- ✅ تسجيل Custom Post Type للكتب

---

## ⚙️ الإعداد | Setup

### 1. إنشاء القوائم (Menus)

```
المظهر → القوائم → إنشاء قائمة جديدة

قائمة رئيسية (Primary):
- الرئيسية
- المكتبة
- كتبي
- حسابي

قائمة التذييل (Footer):
- عن الموقع
- سياسة الخصوصية
- الشروط والأحكام
- اتصل بنا
```

### 2. إنشاء الصفحات الأساسية

#### صفحة "قراءة الكتاب"
```
الصفحات → أضف جديداً
العنوان: قراءة الكتاب
الرابط: /read-book/
القالب: قراءة الكتاب
نشر
```

#### صفحة "المكتبة"
```
الصفحات → أضف جديداً
العنوان: المكتبة
اعرض أرشيف الكتب أو استخدم WooCommerce
نشر
```

### 3. إعداد WooCommerce

```
WooCommerce → الإعدادات

عام:
- اختر العملة (جنيه مصري)
- حدد الدولة (مصر)

المنتجات:
- تفعيل "تنزيلات"
- تفعيل "المنتجات الافتراضية"

الشحن:
- إلغاء جميع طرق الشحن (منتجات رقمية)

المدفوعات:
- فعّل الطرق المطلوبة:
  ✅ التحويل البنكي
  ✅ PayPal
  ✅ Stripe
  ✅ أي بوابة دفع مصرية
```

---

## 📖 دليل الاستخدام | Usage Guide

### إضافة كتاب جديد

#### الطريقة 1: عبر Custom Post Type

```
1. الكتب الرقمية → إضافة كتاب
2. املأ التفاصيل:
   - العنوان
   - الوصف
   - صورة الغلاف
   - التصنيف
3. في قسم "تفاصيل الكتاب":
   - اترك Product ID فارغاً (سيُنشأ تلقائياً)
   - ارفع ملف PDF
4. اضغط "نشر"

✨ سيتم إنشاء WooCommerce Product تلقائياً!
```

#### الطريقة 2: عبر WooCommerce (للتحكم الكامل)

```
1. المنتجات → أضف جديداً
2. املأ تفاصيل المنتج
3. نوع المنتج: "Simple Product"
4. فعّل: "Virtual" و "Downloadable"
5. حدد السعر
6. في التبويب "عام":
   - أضف ملف للتحميل (PDF)
7. نشر

ثم:
8. الكتب الرقمية → إضافة كتاب
9. في "تفاصيل الكتاب":
   - أدخل Product ID
   - ارفع نفس ملف PDF
10. نشر
```

### إضافة ملفات صوتية

```
1. الكتب الرقمية → تعديل الكتاب
2. في قسم "الملفات الصوتية":
   - رقم الصفحة: 5 (مثلاً)
   - ملف الصوت: اختر MP3
   - الوصف: (اختياري)
3. اضغط "نشر" أو "تحديث"

🎧 سيتم تشغيل الصوت تلقائياً عند الوصول للصفحة 5
```

### تحديد سعر كتاب

السعر يُدار بالكامل عبر WooCommerce:

```
1. المنتجات → جميع المنتجات
2. ابحث عن الكتاب
3. اضغط "تحرير سريع"
4. حدد السعر
5. تحديث

أو:
1. المنتجات → تعديل المنتج
2. في التبويب "عام":
   - السعر العادي: 99
   - سعر التخفيض: 79 (اختياري)
3. تحديث
```

---

## 🛒 كيف يعمل نظام الشراء؟

### رحلة المستخدم:

```
1. المستخدم يتصفح الكتب
   ↓
2. يضغط "شراء الكتاب"
   ↓
3. ينتقل لصفحة المنتج في WooCommerce
   ↓
4. يضيف للسلة → "إتمام الطلب"
   ↓
5. يدخل بيانات الدفع (Checkout)
   ↓
6. يدفع عبر بوابة الدفع (PayPal/Stripe/etc)
   ↓
7. بعد الدفع الناجح:
   ✅ يظهر زر "ابدأ القراءة الآن"
   ✅ يمكن تحميل PDF من "حسابي"
   ✅ يمكن القراءة أونلاين فوراً
```

### للمستخدمين المسجلين دخولهم:

```
حسابي → Downloads → تحميل PDF
حسابي → كتبي → قراءة أونلاين
```

---

## 🎯 الميزات الخاصة بـ WooCommerce

### 1. إنشاء تلقائي للمنتجات
عند إضافة كتاب، يتم تلقائياً:
- إنشاء WooCommerce Product
- نقل العنوان والوصف
- نقل صورة الغلاف
- ربط التصنيفات
- إضافة SKU: BOOK-{ID}

### 2. My Account → كتبي
قسم جديد في صفحة حسابي:
```
WooCommerce → My Account → كتبي

يعرض جميع الكتب المشتراة
مع زر "قراءة الآن" لكل كتاب
```

### 3. زر "قراءة الآن" في صفحة المنتج
```
إذا اشترى المستخدم الكتاب:
  - يختفي زر "أضف للسلة"
  - يظهر زر "قراءة الآن"
```

### 4. صفحة الشكر (Thank You Page)
```
بعد إتمام الشراء:
  - رسالة ترحيبية
  - زر كبير "📖 ابدأ القراءة الآن"
  - رابط مباشر للقراءة
```

### 5. تحميل PDF تلقائي
```
بعد إتمام الطلب:
  - يُضاف PDF تلقائياً كـ Download
  - يظهر في حسابي → Downloads
  - رابط تحميل صالح (حسب إعدادات WooCommerce)
```

---

## 📂 هيكل الملفات | File Structure

```
digital-books-theme/
├── style.css                    # معلومات الثيم + CSS أساسي
├── functions.php                # الوظائف الرئيسية
├── header.php                   # الهيدر
├── footer.php                   # الفوتر
├── index.php                    # الصفحة الرئيسية
├── page-read-book.php           # صفحة القراءة
├── screenshot.png               # صورة الثيم (1200x900)
│
├── inc/                         # الملفات الإضافية
│   ├── woocommerce-integration.php   # تكامل WooCommerce
│   └── template-functions.php        # وظائف القوالب
│
├── templates/                   # القوالب
│   └── pdf-viewer.php          # قارئ PDF
│
├── assets/                      # الأصول
│   ├── css/
│   │   └── (ملفات CSS إضافية)
│   ├── js/
│   │   └── main.js             # JavaScript الرئيسي
│   └── images/
│
└── woocommerce/                # تخصيص WooCommerce (اختياري)
    ├── single-product/
    ├── cart/
    └── checkout/
```

---

## 🎨 التخصيص | Customization

### تغيير الألوان

في `style.css`:

```css
:root {
    --primary-color: #667eea;     /* اللون الأساسي */
    --secondary-color: #764ba2;   /* اللون الثانوي */
    --accent-color: #38ef7d;      /* لون التمييز */
}
```

### تخصيص WooCommerce

إنشاء ملفات تخصيص في:
```
wp-content/themes/digital-books-theme/woocommerce/
```

مثال - تخصيص صفحة المنتج:
```
woocommerce/single-product/title.php
woocommerce/single-product/price.php
```

### إضافة CSS مخصص

```
المظهر → تخصيص → CSS إضافي

أو

إنشاء ملف: assets/css/custom.css
ثم إضافته في functions.php
```

---

## 🔌 Hooks & Filters

### Actions (الأحداث)

```php
// بعد إنشاء كتاب جديد
add_action('save_post_book', function($post_id, $post, $update) {
    // Your code
}, 10, 3);

// بعد تفعيل الثيم
add_action('after_switch_theme', function() {
    // Your code
});
```

### Filters (الفلاتر)

```php
// تعديل عدد الكتب المعروضة
add_filter('posts_per_page', function($posts_per_page) {
    if (is_post_type_archive('book')) {
        return 16;
    }
    return $posts_per_page;
});

// تخصيص معلومات المنتج
add_filter('woocommerce_product_tabs', function($tabs) {
    $tabs['book_info'] = array(
        'title' => __('معلومات الكتاب', 'digital-books-theme'),
        'priority' => 50,
        'callback' => 'display_book_info_tab'
    );
    return $tabs;
});
```

---

## 💡 أمثلة الاستخدام | Usage Examples

### مثال 1: عرض كتب تصنيف معين

```php
// في أي template file
$books = dbt_get_books_by_category('programming', 12);

if ($books->have_posts()) {
    echo '<div class="books-grid">';
    while ($books->have_posts()) {
        $books->the_post();
        dbt_display_book_card(get_the_ID());
    }
    echo '</div>';
    wp_reset_postdata();
}
```

### مثال 2: التحقق من شراء المستخدم

```php
$user_id = get_current_user_id();
$product_id = 123; // ID المنتج

if (dbt_user_has_purchased_book($user_id, $product_id)) {
    echo 'يمكنك قراءة هذا الكتاب!';
    echo '<a href="/read-book/?book_id=' . $book_id . '">قراءة الآن</a>';
} else {
    echo 'يجب شراء الكتاب أولاً';
}
```

### مثال 3: عرض تقدم القراءة

```php
$user_id = get_current_user_id();
$book_id = 45;

$current_page = dbt_get_reading_progress($user_id, $book_id);

echo "أنت في الصفحة: " . $current_page;
```

---

## 🐛 استكشاف الأخطاء | Troubleshooting

### مشكلة: "WooCommerce is required"

**الحل:**
```
1. تثبيت بلاجن WooCommerce
2. تفعيل البلاجن
3. إعادة تفعيل الثيم
```

### مشكلة: المنتجات لا تُنشأ تلقائياً

**الحل:**
```php
// في functions.php تأكد من:
add_action('save_post_book', 'dbt_create_woocommerce_product_for_book', 20, 3);

// تحقق من Logs:
WooCommerce → الحالة → Logs
```

### مشكلة: PDF لا يعرض

**الحل:**
```
1. تحقق من أذونات المجلد:
   chmod 755 wp-content/uploads/dbt-books/

2. تحقق من رابط الملف
3. تحقق من Console في المتصفح
4. تأكد من تحميل PDF.js
```

### مشكلة: الصوت لا يشتغل

**الحل:**
```
1. تحقق من صيغة الملف (MP3 مفضل)
2. تحقق من أذونات المجلد:
   chmod 755 wp-content/uploads/dbt-audio/
3. تحقق من رابط الملف في الصفحة
```

### مشكلة: Checkout لا يعمل

**الحل:**
```
1. تحقق من إعدادات WooCommerce
2. فعّل طريقة دفع واحدة على الأقل
3. امسح Cache
4. تحقق من Permalinks (إعادة حفظ)
```

---

## ⌨️ اختصارات لوحة المفاتيح | Keyboard Shortcuts

في قارئ PDF:

| الاختصار | الوظيفة |
|----------|---------|
| `←` | الصفحة التالية (RTL) |
| `→` | الصفحة السابقة (RTL) |
| `+` أو `=` | تكبير |
| `-` | تصغير |
| `F` | ملء الشاشة |
| `S` | حفظ التقدم |

---

## 📊 قاعدة البيانات | Database Tables

```sql
wp_dbt_books           # معلومات الكتب الإضافية
wp_dbt_audio           # الملفات الصوتية
wp_dbt_progress        # تقدم القراءة
wp_dbt_saved_books     # الكتب المحفوظة
```

---

## 🚀 نصائح الأداء | Performance Tips

### 1. استخدم CDN
```php
// لتحميل PDF.js أسرع، استخدم CDN
```

### 2. تفعيل Caching
```
استخدم:
- WP Super Cache
- W3 Total Cache
- LiteSpeed Cache
```

### 3. ضغط الصور
```
استخدم:
- Smush
- EWWW Image Optimizer
- ShortPixel
```

### 4. تحسين قاعدة البيانات
```sql
OPTIMIZE TABLE wp_dbt_books;
OPTIMIZE TABLE wp_dbt_audio;
OPTIMIZE TABLE wp_dbt_progress;
```

---

## 🔒 الأمان | Security

### الميزات الأمنية:

✅ **Nonce Verification** - جميع طلبات AJAX
✅ **SQL Injection Protection** - Prepared Statements
✅ **XSS Protection** - تنقية المدخلات
✅ **CSRF Protection** - حماية النماذج
✅ **File Upload Validation** - فحص أنواع الملفات
✅ **Capability Checks** - فحص صلاحيات المستخدم

### توصيات:

1. ✅ استخدم SSL (HTTPS)
2. ✅ حدّث WordPress وWooCommerce باستمرار
3. ✅ استخدم كلمات مرور قوية
4. ✅ احتفظ بنسخ احتياطية دورية
5. ✅ استخدم أمان WooCommerce الإضافي

---

## ❓ الأسئلة الشائعة | FAQ

### هل يمكن استخدام الثيم بدون WooCommerce؟

لا، WooCommerce مطلوب أساسي للثيم لأن نظام الدفع بالكامل يعتمد عليه.

### هل يمكن بيع منتجات أخرى غير الكتب؟

نعم! WooCommerce يدعم أي نوع من المنتجات. الثيم مصمم للكتب لكن لا يمنع بيع منتجات أخرى.

### ما هي طرق الدفع المدعومة؟

جميع طرق الدفع التي يدعمها WooCommerce:
- التحويل البنكي
- PayPal
- Stripe
- 2Checkout
- بوابات الدفع المصرية (Fawry, Paymob, etc)

### هل يمكن تحديد صلاحيات التحميل؟

نعم! عبر إعدادات WooCommerce:
```
WooCommerce → الإعدادات → المنتجات → تنزيلات
- عدد مرات التحميل المسموح
- صلاحية رابط التحميل (أيام)
```

### هل الثيم متوافق مع WPML للترجمة؟

نعم، الثيم Translation-Ready ويدعم:
- WPML
- Polylang
- Loco Translate

---

## 🆕 التحديثات | Changelog

### الإصدار 1.0.0 (2024)
- ✨ الإصدار الأول
- ✅ دمج كامل مع WooCommerce
- ✅ إنشاء تلقائي للمنتجات
- ✅ قارئ PDF متقدم
- ✅ نظام صوتي مع QR Codes
- ✅ حفظ تقدم القراءة
- ✅ تصميم عصري متجاوب

---

## 📞 الدعم | Support

### للحصول على الدعم:

📧 **Email:** support@netlabacademy.com
💬 **WhatsApp:** +20XXXXXXXXXX
🌐 **Website:** https://netlabacademy.com
📚 **Documentation:** https://docs.netlabacademy.com

---

## 📄 الترخيص | License

هذا الثيم مرخص تحت **GPL-2.0+**

```
Digital Books Theme - WordPress Theme
Copyright (C) 2024

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
```

---

## 🙏 شكر وتقدير | Credits

### التقنيات المستخدمة:

- **[WordPress](https://wordpress.org/)** - CMS Platform
- **[WooCommerce](https://woocommerce.com/)** - E-Commerce Solution
- **[PDF.js](https://mozilla.github.io/pdf.js/)** by Mozilla - PDF Viewer
- **[SweetAlert2](https://sweetalert2.github.io/)** - Beautiful Alerts
- **[Cairo Font](https://fonts.google.com/specimen/Cairo)** - Arabic Typography

---

<div align="center">

**صنع بـ ❤️ من أجل مجتمع القراءة العربي**

Made with ❤️ for the Arabic Reading Community

---

**النسخة:** 1.0.0 | **آخر تحديث:** 2024

[الموقع](https://netlabacademy.com) • [التوثيق](https://docs.netlabacademy.com) • [الدعم](https://support.netlabacademy.com)

</div>
