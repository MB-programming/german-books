# منصة الكتب الرقمية - Digital Books Platform

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.8+-green.svg)
![PHP](https://img.shields.io/badge/PHP-7.4+-purple.svg)
![License](https://img.shields.io/badge/license-GPL--2.0+-red.svg)

**منصة متكاملة لإدارة وعرض الكتب الرقمية بصيغة PDF مع نظام صوتي وQR Codes**

A complete WordPress plugin for managing and displaying digital PDF books with audio support and QR code integration.

---

## 📋 المحتويات | Contents

- [المميزات](#-المميزات--features)
- [المتطلبات](#-المتطلبات--requirements)
- [التثبيت](#-التثبيت--installation)
- [الإعداد الأولي](#-الإعداد-الأولي--initial-setup)
- [دليل الاستخدام](#-دليل-الاستخدام--usage-guide)
- [الـ Shortcodes](#-الـ-shortcodes)
- [نظام الدفع](#-نظام-الدفع--payment-system)
- [الأسئلة الشائعة](#-الأسئلة-الشائعة--faq)
- [الدعم الفني](#-الدعم-الفني--support)

---

## ✨ المميزات | Features

### 📚 إدارة الكتب
- ✅ رفع وإدارة كتب PDF بشكل كامل
- ✅ صور غلاف للكتب
- ✅ تصنيفات مخصصة للكتب
- ✅ كتب مجانية ومدفوعة
- ✅ وصف تفصيلي لكل كتاب

### 🎧 نظام الصوت المتقدم
- ✅ ربط ملفات صوتية بصفحات محددة من الكتاب
- ✅ QR Codes لكل صفحة تحتوي على صوت
- ✅ تشغيل تلقائي للصوت عند الانتقال للصفحة
- ✅ مشغل صوتي متقدم مع عناصر تحكم كاملة

### 📖 قارئ PDF احترافي
- ✅ عرض PDF بجودة عالية مع PDF.js 3.11.174
- ✅ إمكانية تحديد ونسخ النص من الكتاب
- ✅ تكبير وتصغير (50% - 300%)
- ✅ وضع ملء الشاشة
- ✅ الروابط داخل PDF تفتح في تاب جديد
- ✅ حفظ تقدم القراءة تلقائياً
- ✅ اختصارات لوحة المفاتيح

### 💳 نظام الدفع المتكامل
- ✅ دعم InstaPay
- ✅ دعم Vodafone Cash
- ✅ نظام طلبات الشراء
- ✅ موافقة/رفض الطلبات من لوحة الإدارة
- ✅ تكامل مع WhatsApp للتواصل

### 👥 إدارة المستخدمين
- ✅ صلاحيات مخصصة للمحررين
- ✅ مكتبة شخصية لكل مستخدم
- ✅ حفظ التقدم في القراءة
- ✅ سجل المشتريات

### 🎨 واجهة مستخدم حديثة
- ✅ تصميم عصري مع Gradients جذابة
- ✅ SweetAlert2 لجميع الإشعارات
- ✅ متجاوب مع جميع الشاشات
- ✅ دعم RTL كامل للعربية
- ✅ Dark Mode Support

---

## 🔧 المتطلبات | Requirements

| المتطلب | الإصدار المطلوب |
|---------|-----------------|
| WordPress | 5.8 أو أحدث |
| PHP | 7.4 أو أحدث |
| MySQL | 5.6 أو أحدث |
| الذاكرة | 128MB على الأقل |
| مساحة التخزين | 500MB على الأقل |

### المكتبات المستخدمة:
- **PDF.js** v3.11.174 - لعرض ملفات PDF
- **SweetAlert2** v11 - للإشعارات الجميلة
- **jQuery** - مضمن مع WordPress

---

## 📥 التثبيت | Installation

### الطريقة 1: التثبيت عبر لوحة تحكم WordPress

1. **تحميل البلاجن:**
   - قم بتحميل ملف `digital-books-platform.zip`

2. **رفع البلاجن:**
   ```
   لوحة التحكم → إضافات → أضف جديد → رفع إضافة
   ```
   - اختر ملف ZIP
   - اضغط "التثبيت الآن"

3. **تفعيل البلاجن:**
   - بعد التثبيت، اضغط "تفعيل الإضافة"

### الطريقة 2: التثبيت اليدوي عبر FTP

1. **رفع الملفات:**
   ```bash
   # قم بفك ضغط الملف ورفع المجلد إلى:
   /wp-content/plugins/digital-books-platform/
   ```

2. **تعيين الصلاحيات:**
   ```bash
   chmod -R 755 wp-content/plugins/digital-books-platform/
   chmod -R 777 wp-content/uploads/dbp-books/
   chmod -R 777 wp-content/uploads/dbp-audio/
   ```

3. **تفعيل البلاجن:**
   - اذهب إلى: لوحة التحكم → إضافات
   - فعّل "منصة الكتب الرقمية"

---

## ⚙️ الإعداد الأولي | Initial Setup

### 1. إعداد أذونات الملفات

سيقوم البلاجن تلقائياً بإنشاء المجلدات التالية:
```
wp-content/uploads/dbp-books/    (لتخزين ملفات PDF)
wp-content/uploads/dbp-audio/    (لتخزين ملفات الصوت)
```

### 2. إعداد نظام الدفع

```
لوحة التحكم → الكتب الرقمية → الإعدادات
```

قم بملء البيانات التالية:
- ✏️ رقم InstaPay
- ✏️ رقم Vodafone Cash
- ✏️ رقم WhatsApp (للتواصل مع العملاء)
- ☑️ تفعيل/إلغاء تفعيل نظام الدفع

### 3. إضافة الصفحات الأساسية

قم بإنشاء الصفحات التالية وأضف الـ Shortcodes المناسبة:

#### صفحة "المكتبة" أو "جميع الكتب"
```
[dbp_books_list]
```

#### صفحة "كتبي"
```
[dbp_my_books]
```

#### صفحة "قراءة الكتاب"
```
[dbp_pdf_viewer]
```

---

## 📖 دليل الاستخدام | Usage Guide

### إضافة كتاب جديد

1. **اذهب إلى:**
   ```
   الكتب الرقمية → إضافة كتاب
   ```

2. **املأ البيانات:**
   - 📝 عنوان الكتاب (مطلوب)
   - 📄 وصف الكتاب
   - 📁 ملف PDF (مطلوب - حد أقصى 50MB)
   - 🖼️ صورة الغلاف (اختياري)
   - 🏷️ الفئة/التصنيف
   - 💰 نوع الكتاب (مجاني/مدفوع)
   - 💵 السعر (بالجنيه المصري)

3. **اضغط "إضافة الكتاب"**

### إضافة ملف صوتي لصفحة

1. **اذهب إلى:**
   ```
   الكتب الرقمية → جميع الكتب → تعديل الكتاب
   ```

2. **في قسم "الملفات الصوتية":**
   - 🔢 رقم الصفحة
   - 🎵 ملف الصوت (MP3 مفضل)
   - 📝 وصف الصوت (اختياري)

3. **اضغط "إضافة صوت"**

### إدارة طلبات الشراء

1. **اذهب إلى:**
   ```
   الكتب الرقمية → طلبات الشراء
   ```

2. **ستجد قائمة بجميع الطلبات:**
   - 👤 اسم المستخدم
   - 📚 اسم الكتاب
   - 💰 المبلغ
   - 💳 طريقة الدفع
   - 📊 الحالة (قيد الانتظار/مقبول/مرفوض)

3. **لكل طلب قيد الانتظار:**
   - ✅ زر "موافقة" - لتفعيل الكتاب للمستخدم
   - ❌ زر "رفض" - لرفض الطلب

---

## 🎯 الـ Shortcodes

### 1. عرض جميع الكتب
```php
[dbp_books_list]
```

**مع معاملات اختيارية:**
```php
[dbp_books_list category="برمجة" paid="0" limit="12"]
```

**المعاملات:**
- `category` - تصفية حسب الفئة
- `paid` - 0 للمجاني، 1 للمدفوع
- `limit` - عدد الكتب المعروضة (افتراضي: 12)

### 2. عرض كتب المستخدم
```php
[dbp_my_books]
```

يعرض الكتب المحفوظة للمستخدم المسجل دخوله.

### 3. قارئ PDF
```php
[dbp_pdf_viewer]
```

يعرض قارئ PDF الكامل. يتم تمرير `book_id` عبر URL:
```
https://yoursite.com/read-book/?book_id=123
```

---

## 💳 نظام الدفع | Payment System

### كيف يعمل؟

#### 1. طلب الشراء من المستخدم
```
المستخدم → يضغط "شراء الكتاب" → يختار طريقة الدفع
→ يحول المبلغ → يضغط "إرسال طلب الشراء"
```

#### 2. معالجة الطلب من المسؤول
```
الإدارة → طلبات الشراء → التحقق من الدفع
→ موافقة → يتم تفعيل الكتاب للمستخدم
```

#### 3. الوصول للكتاب
```
المستخدم → كتبي → يجد الكتاب المشترى → قراءة
```

### طرق الدفع المدعومة

| الطريقة | الوصف |
|---------|-------|
| 💳 InstaPay | التحويل الفوري عبر InstaPay |
| 📱 Vodafone Cash | الدفع عبر فودافون كاش |

### تكامل WhatsApp

بعد إرسال طلب الشراء، يظهر للمستخدم زر "تواصل عبر واتساب" للتأكيد السريع.

---

## 🎨 التخصيص | Customization

### تخصيص الألوان

يمكنك تخصيص ألوان البلاجن عبر إضافة CSS مخصص:

```css
/* تغيير اللون الأساسي */
.dbp-book-card .button {
    background: linear-gradient(135deg, #YOUR_COLOR_1 0%, #YOUR_COLOR_2 100%);
}

/* تغيير لون النص */
.dbp-book-card h3 {
    color: #YOUR_COLOR;
}
```

### تخصيص القالب

يمكنك نسخ ملفات القوالب إلى theme الخاص بك:

```
نسخ من: wp-content/plugins/digital-books-platform/public/
نسخ إلى: wp-content/themes/YOUR_THEME/digital-books-platform/
```

---

## 🔌 Hooks & Filters

### Actions (أحداث قابلة للتنفيذ)

```php
// بعد إضافة كتاب جديد
add_action('dbp_book_added', function($book_id) {
    // Your code here
});

// بعد موافقة على طلب شراء
add_action('dbp_purchase_approved', function($user_id, $book_id) {
    // Your code here
}, 10, 2);

// بعد حفظ تقدم القراءة
add_action('dbp_progress_saved', function($user_id, $book_id, $page) {
    // Your code here
}, 10, 3);
```

### Filters (فلاتر لتعديل البيانات)

```php
// تعديل عدد الكتب المعروضة
add_filter('dbp_books_per_page', function($limit) {
    return 20; // بدلاً من 12
});

// تعديل حجم الغلاف
add_filter('dbp_cover_image_size', function($size) {
    return array(400, 600); // width, height
});

// تعديل طرق الدفع
add_filter('dbp_payment_methods', function($methods) {
    $methods['paypal'] = 'PayPal';
    return $methods;
});
```

---

## ⌨️ اختصارات لوحة المفاتيح | Keyboard Shortcuts

في قارئ PDF:

| الاختصار | الوظيفة |
|----------|---------|
| `←` | الصفحة التالية (RTL) |
| `→` | الصفحة السابقة (RTL) |
| `+` أو `=` | تكبير |
| `-` | تصغير |
| `F` | ملء الشاشة |
| `S` | حفظ التقدم |

---

## 📊 قاعدة البيانات | Database

### الجداول المُنشأة:

```sql
wp_dbp_books              # الكتب
wp_dbp_audio              # الملفات الصوتية
wp_dbp_saved_books        # الكتب المحفوظة
wp_dbp_progress           # تقدم القراءة
wp_dbp_purchases          # المشتريات
wp_dbp_purchase_requests  # طلبات الشراء
```

### النسخ الاحتياطي

يُنصح بعمل نسخة احتياطية من قاعدة البيانات قبل أي تحديث:

```bash
# عبر phpMyAdmin أو:
mysqldump -u username -p database_name > backup.sql
```

---

## 🔒 الأمان | Security

### الميزات الأمنية المدمجة:

✅ **Nonce Verification** - جميع طلبات AJAX محمية
✅ **SQL Injection Protection** - استخدام Prepared Statements
✅ **XSS Protection** - تنقية جميع المدخلات
✅ **CSRF Protection** - حماية من هجمات CSRF
✅ **File Upload Validation** - فحص أنواع الملفات
✅ **Capability Checks** - فحص صلاحيات المستخدم

### توصيات الأمان:

1. ✅ استخدم كلمات مرور قوية
2. ✅ احتفظ بنسخ احتياطية دورية
3. ✅ حدّث WordPress والبلاجن باستمرار
4. ✅ استخدم SSL (HTTPS) لموقعك
5. ✅ قيّد الصلاحيات حسب الحاجة

---

## 🐛 استكشاف الأخطاء | Troubleshooting

### مشكلة: لا تظهر الكتب

**الحل:**
```php
// تحقق من أذونات المجلدات
chmod -R 755 wp-content/uploads/dbp-books/
```

### مشكلة: لا يعمل رفع الملفات

**الحل:**
```php
// في wp-config.php أضف:
define('WP_MEMORY_LIMIT', '256M');

// في .htaccess أضف:
php_value upload_max_filesize 50M
php_value post_max_size 50M
```

### مشكلة: PDF لا يعرض بشكل صحيح

**الحل:**
- تأكد من تحميل PDF.js بشكل صحيح
- افتح Console في المتصفح وتحقق من الأخطاء
- جرّب مسح Cache المتصفح

### مشكلة: الصوت لا يشتغل

**الحل:**
```php
// تحقق من:
1. صيغة الملف الصوتي (MP3 مفضل)
2. أذونات مجلد dbp-audio
3. رابط الملف في الصفحة
```

---

## ❓ الأسئلة الشائعة | FAQ

### هل يدعم البلاجن WooCommerce؟

حالياً، البلاجن يحتوي على نظام دفع خاص (InstaPay/Vodafone Cash). يمكن إضافة تكامل WooCommerce في الإصدارات القادمة.

### هل يمكن تحويل البلاجن لدعم لغات أخرى؟

نعم! البلاجن جاهز للترجمة. يمكن استخدام ملفات .po و .mo للترجمة.

### ما هو الحد الأقصى لحجم ملف PDF؟

افتراضياً 50MB، لكن يمكن زيادته من إعدادات PHP:
```ini
upload_max_filesize = 100M
post_max_size = 100M
```

### هل يعمل مع أي Theme؟

نعم! البلاجن مصمم للعمل مع جميع WordPress Themes.

### هل البلاجن مجاني؟

نعم، هذا الإصدار مجاني ومفتوح المصدر.

---

## 🔄 التحديثات | Updates

### الإصدار 1.0.0 (2024)
- ✨ الإصدار الأول
- ✅ نظام إدارة الكتب
- ✅ قارئ PDF متقدم
- ✅ نظام الصوت مع QR Codes
- ✅ نظام الدفع (InstaPay/Vodafone Cash)
- ✅ إدارة المستخدمين

### خارطة الطريق (Roadmap)

#### قريباً:
- 🔜 تكامل مع WooCommerce
- 🔜 نظام التقييمات والمراجعات
- 🔜 إحصائيات متقدمة
- 🔜 تصدير البيانات

---

## 👨‍💻 التطوير | Development

### هيكل الملفات:

```
digital-books-platform/
├── digital-books-platform.php  # الملف الرئيسي
├── README.md                   # هذا الملف
├── includes/                   # الـ Classes الأساسية
│   ├── class-dbp-database.php
│   ├── class-dbp-roles.php
│   ├── class-dbp-books.php
│   ├── class-dbp-audio.php
│   ├── class-dbp-payments.php
│   └── class-dbp-progress.php
├── admin/                      # صفحات الإدارة
│   ├── class-dbp-admin.php
│   ├── class-dbp-admin-books.php
│   ├── class-dbp-admin-payments.php
│   └── class-dbp-admin-settings.php
├── public/                     # الواجهة الأمامية
│   ├── class-dbp-public.php
│   ├── class-dbp-shortcodes.php
│   └── class-dbp-pdf-viewer.php
└── assets/                     # CSS و JS
    ├── css/
    │   ├── admin.css
    │   └── public.css
    └── js/
        ├── admin.js
        └── public.js
```

### المساهمة في التطوير:

نرحب بالمساهمات! يرجى:
1. Fork المشروع
2. إنشاء Branch جديد للميزة
3. Commit التغييرات
4. Push وإنشاء Pull Request

---

## 📞 الدعم الفني | Support

### للحصول على الدعم:

📧 **Email:** [email protected]
💬 **WhatsApp:** +20XXXXXXXXXX
🌐 **Website:** https://netlabacademy.com

### الإبلاغ عن مشكلة:

إذا وجدت مشكلة، يرجى تضمين:
- إصدار WordPress
- إصدار PHP
- وصف تفصيلي للمشكلة
- لقطة شاشة (إن أمكن)
- رسائل الخطأ من Console

---

## 📄 الترخيص | License

هذا البلاجن مرخص تحت **GPL-2.0+**
يمكنك استخدامه، تعديله، وتوزيعه بحرية.

```
Digital Books Platform - WordPress Plugin
Copyright (C) 2024

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
```

---

## 🙏 شكر وتقدير | Credits

### المكتبات المستخدمة:

- [PDF.js](https://mozilla.github.io/pdf.js/) by Mozilla
- [SweetAlert2](https://sweetalert2.github.io/) by sweetalert2
- [WordPress](https://wordpress.org/) CMS

### شكر خاص:

- فريق WordPress لتطوير منصة رائعة
- مجتمع المطورين العرب
- جميع المساهمين في المشروع

---

## 📝 ملاحظات إضافية | Additional Notes

### الأداء:

- تم تحسين البلاجن للأداء العالي
- يستخدم Caching عند الإمكان
- Lazy Loading للصور
- تحميل Scripts فقط عند الحاجة

### التوافق:

- ✅ PHP 7.4+
- ✅ PHP 8.0+
- ✅ PHP 8.1+
- ✅ WordPress 5.8+
- ✅ WordPress 6.0+

### المتصفحات المدعومة:

- ✅ Chrome/Edge (Latest)
- ✅ Firefox (Latest)
- ✅ Safari (Latest)
- ✅ Mobile Browsers

---

## 🚀 البدء السريع | Quick Start

### في 5 دقائق:

```bash
# 1. رفع البلاجن
Upload → wp-content/plugins/

# 2. تفعيل البلاجن
WordPress Dashboard → Plugins → Activate

# 3. إعداد الدفع
Digital Books → Settings → Enter Payment Info

# 4. إضافة كتاب
Digital Books → Add Book → Upload PDF

# 5. إضافة Shortcode
Create Page → Add [dbp_books_list] → Publish

# 🎉 جاهز!
```

---

<div align="center">

**صنع بـ ❤️ من أجل مجتمع القراءة العربي**

Made with ❤️ for the Arabic Reading Community

---

**النسخة:** 1.0.0 | **آخر تحديث:** 2024

[الموقع](https://netlabacademy.com) • [التوثيق](https://docs.netlabacademy.com) • [الدعم](https://support.netlabacademy.com)

</div>
